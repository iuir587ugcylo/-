# a = input()
# e=0
# for i in range(a.__len__()):
#     if a[i]=="a":
#         e+=1
#     elif a[i]=="b":
#         e+=1
#     elif a[i]=="c":
#         e+=1
#     elif a[i]=="d":
#         e+=1
