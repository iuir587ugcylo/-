# number=0
# while number<5:
#     print(f"number={number}")
#     number+=1
# print("End")
# import math
#
# x=int(input())
# y=int(input())
# z=int(input())
#
# w=(math.fabs(math.cos(x)-math.cos(y))**(1+2*math.sin(y)**2))*(1+z+z**2/2+z**2/3+z**4/4)
# print(x,z,y,w)
# import math
#
# x=int(input())
# y=int(input())
# z=int(input())
#
# r=(math.e**math.fabs(x-y)*math.fabs(x-y)**(x+y)/math.atan(x)+math.atan(z))+((x**6+math.log(y)**2)**1/3)
# print(x,y,z,r)
