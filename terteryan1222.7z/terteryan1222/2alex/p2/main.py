import math

b=int(input())
z1 =math.cos(3/8*math.pi-b/4)**2-math.cos(11/8*math.pi+b/4)**2
z2 = math.sqrt(2)/2*math.sin(b/2)

print(z1)
print(z2)

import math

b=int(input())
a=int(input())
z1 =math.cos(a)-math.cos(b)**2-math.sin(a)-math.sin(b)**2
# z2 =-4*math.pow(math.sin((a-b)/2),2)*math.cos(a+b))
z2= -4*math.pow(math.sin((a-b)/2),2)*math.cos(a+b)
print(z1)
print(z2)