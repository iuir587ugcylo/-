# a = input()
# e=0
# for i in range(a.__len__()):
#     if a[i]=="a":
#         e+=1
#     elif a[i]=="b":
#         e+=1
#     elif a[i]=="c":
#         e+=1
#     elif a[i]=="d":
#         e+=1
def print_check(honey):
    sum =  0 # переменная для накопления общей суммы
    print("кукла\n")
    # в цикле будем выводить название , количество и цену
    name = honey[0]
    amount = honey[1]
    price = honey[2]
    print(f"{name} ({amount} шт.) - {price} руб.")
    print("ок")

print_check(["name", "amount", "price"])
